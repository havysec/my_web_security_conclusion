<?php 
$test = $_GET['cmd']; 
system("ls -al '$test'"); 
?>